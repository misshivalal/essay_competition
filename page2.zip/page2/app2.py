

from flask import Flask, render_template, request, redirect, url_for, flash, send_file
import sqlite3
import csv
from datetime import datetime
import os
import logging

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Set up logging for debugging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Ensure the static/uploads folder exists
UPLOAD_FOLDER = 'static/uploads'
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

# Ensure the static/files folder exists
FILES_FOLDER = 'static/files'
if not os.path.exists(FILES_FOLDER):
    os.makedirs(FILES_FOLDER)

# SQLite Database Setup
def init_db():
    conn = sqlite3.connect('students.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS students 
                 (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, class TEXT, school_name TEXT, 
                  contact_number TEXT, email TEXT, id_card TEXT, registration_date TEXT)''')
    conn.commit()
    conn.close()

# Home Page (Public access)
@app.route('/')
def home():
    return render_template('home.html')

# Register Page (Student registration)
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        class_name = request.form['class']
        school_name = request.form['school_name']
        contact_number = request.form['contact_number']
        email = request.form['email']
        
        # Handle ID Card File Upload
        file = request.files['id_card']
        if file:
            filename = file.filename
            filepath = os.path.join(UPLOAD_FOLDER, filename)
            file.save(filepath)
        else:
            flash('No file selected for upload.')
            return redirect(url_for('register'))
        
        # Insert data into database
        try:
            conn = sqlite3.connect('students.db')
            c = conn.cursor()
            registration_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            c.execute("INSERT INTO students (name, class, school_name, contact_number, email, id_card, registration_date) VALUES (?, ?, ?, ?, ?, ?, ?) ",
                      (name, class_name, school_name, contact_number, email, filename, registration_date))
            student_id = c.lastrowid
            conn.commit()
        except sqlite3.Error as e:
            flash(f"Database error: {e}")
            return redirect(url_for('register'))
        finally:
            conn.close()

        return redirect(url_for('welcome_student', student_id=student_id))
    
    return render_template('student_registration.html')

@app.route('/welcome/<int:student_id>')
def welcome_student(student_id):
    try:
        conn = sqlite3.connect('students.db')
        c = conn.cursor()
        c.execute("SELECT * FROM students WHERE id=?", (student_id,))
        student = c.fetchone()
    except sqlite3.Error as e:
        flash(f"Database error: {e}")
        student = None
    finally:
        conn.close()
    
    if not student:
        flash("Student not found.")
        return redirect(url_for('register'))
    
    return render_template('welcome.html', student=student)

# Admin Login Page
@app.route('/admin_login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        if username == 'admin' and password == 'admin123':
            return redirect(url_for('admin_dashboard'))
        else:
            flash('Invalid credentials. Try again.')
            return redirect(url_for('admin_login'))
    
    return render_template('admin_login.html')

@app.route('/admin_logout')
def admin_logout():
    flash('Logged out successfully.')
    return redirect(url_for('admin_login'))

@app.route('/admin_dashboard')
def admin_dashboard():
    try:
        conn = sqlite3.connect('students.db')
        c = conn.cursor()
        c.execute("SELECT * FROM students")
        students = c.fetchall()
    except sqlite3.Error as e:
        flash(f"Database error: {e}")
        students = []
    finally:
        conn.close()
    
    return render_template('admin_dashboard.html', students=students)

# Delete Student Record
@app.route('/delete_student/<int:student_id>', methods=['POST'])
def delete_student(student_id):
    try:
        conn = sqlite3.connect('students.db')
        c = conn.cursor()
        # Delete the student record
        c.execute("DELETE FROM students WHERE id=?", (student_id,))
        conn.commit()
    except sqlite3.Error as e:
        flash(f"Database error: {e}")
    finally:
        conn.close()
    
    flash('Student record deleted successfully.')
    return redirect(url_for('admin_dashboard'))

# Export All Students to CSV
@app.route('/export_all_students', methods=['POST'])
def export_all_students():
    if request.method == 'POST':
        try:
            # Retrieve all student data from the database
            conn = sqlite3.connect('students.db')
            c = conn.cursor()
            c.execute("SELECT * FROM students")
            students = c.fetchall()
        except sqlite3.Error as e:
            flash(f"Database error: {e}")
            return redirect(url_for('admin_dashboard'))
        finally:
            conn.close()

        if not students:
            flash('No data available to export.')
            return redirect(url_for('admin_dashboard'))

        # Define the CSV filename
        filename = f"all_students_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        filepath = os.path.join(FILES_FOLDER, filename)

        try:
            # Write data to CSV file
            with open(filepath, 'w', newline='', encoding='utf-8') as csvfile:
                writer = csv.writer(csvfile)
                writer.writerow(['ID', 'Name', 'Class', 'School', 'Contact Number', 'Email', 'ID Card', 'Registration Date'])  # Header
                writer.writerows(students)

            # Ensure the file exists before attempting to send
            if not os.path.exists(filepath):
                flash('Failed to create the CSV file.')
                return redirect(url_for('admin_dashboard'))            
        except IOError as e:
            flash(f"IO error: {e}")
            return redirect(url_for('admin_dashboard'))

        # Send the CSV file to the client for download
        return send_file(filepath, as_attachment=True)

    return render_template('admin_dashboard.html')

# Export Data to CSV with Date Filter
@app.route('/export_students', methods=['POST'])
def export_students():
    if request.method == 'POST':
        # Retrieve date range from the form
        start_date = request.form['start_date']
        end_date = request.form['end_date']

        # Validate date input
        if not start_date or not end_date:
            flash('Please provide both start and end dates.')
            return redirect(url_for('admin_dashboard'))

        try:
            # Convert string dates to datetime objects
            start_date = datetime.strptime(start_date, '%Y-%m-%d')
            end_date = datetime.strptime(end_date, '%Y-%m-%d')
        except ValueError:
            flash('Invalid date format. Please use YYYY-MM-DD.')
            return redirect(url_for('admin_dashboard'))

        # Retrieve filtered data from the database
        try:
            conn = sqlite3.connect('students.db')
            c = conn.cursor()
            query = "SELECT * FROM students WHERE registration_date BETWEEN ? AND ?"
            c.execute(query, (start_date.strftime('%Y-%m-%d'), end_date.strftime('%Y-%m-%d')))
            students = c.fetchall()
        except sqlite3.Error as e:
            flash(f"Database error: {e}")
            students = []
        finally:
            conn.close()

        if not students:
            flash('No data found for the selected date range.')
            return redirect(url_for('admin_dashboard'))

        # Define the CSV filename
        filename = f"students_{start_date.strftime('%Y%m%d')}_to_{end_date.strftime('%Y%m%d')}.csv"
        filepath = os.path.join(FILES_FOLDER, filename)

        try:
            # Write filtered data to CSV file
            with open(filepath, 'w', newline='', encoding='utf-8') as csvfile:
                writer = csv.writer(csvfile)
                writer.writerow(['ID', 'Name', 'Class', 'School', 'Contact Number', 'Email', 'ID Card', 'Registration Date'])  # Header
                writer.writerows(students)
            
            # Ensure the file exists before attempting to send
            if not os.path.exists(filepath):
                flash('Failed to create the CSV file.')
                return redirect(url_for('admin_dashboard'))                
        except IOError as e:
            flash(f"IO error: {e}")
            return redirect(url_for('admin_dashboard'))

        # Send the CSV file to the client for download
        return send_file(filepath, as_attachment=True)

    return render_template('admin_dashboard.html')

# Admin Topics Page (Just for example)
@app.route('/topics')
def topics():
    essay_topics = ["Environment", "Technology", "Health", "Education", "Space Exploration"]
    return render_template('topics.html', topics=essay_topics)

@app.route('/delete_selected_students', methods=['POST'])
def delete_selected_students():
    # Get the list of selected student IDs from the form
    selected_ids = request.form.getlist('student_ids')
    
    if not selected_ids:
        flash('No students selected for deletion.')
        return redirect(url_for('admin_dashboard'))

# Connect to the database and delete the selected students
    try:
        conn = sqlite3.connect('students.db')
        c = conn.cursor()
        
        # Delete students whose IDs are in the selected list
        c.execute("DELETE FROM students WHERE id IN ({})".format(','.join('?' for _ in selected_ids)), selected_ids)
        conn.commit()
    except sqlite3.Error as e:
        flash(f"Database error: {e}")
    finally:
        conn.close()
    
    flash(f'{len(selected_ids)} student(s) deleted successfully.')
    return redirect(url_for('admin_dashboard'))

if __name__ == '__main__':
    init_db()  # Initialize the database when the app starts
    app.run(debug=True)